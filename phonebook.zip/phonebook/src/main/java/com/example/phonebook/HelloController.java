package com.example.phonebook;

import javafx.application.Preloader;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.*;

public class HelloController implements Initializable{
    @FXML
    private TableView<Contact> tableView;

    //Columns
    @FXML
    private TableColumn<Contact, String> nameColumn;

    @FXML
    private TableColumn<Contact, Integer> phone;

    @FXML
    private TableColumn<Contact, String> Street;
    @FXML
    private TableColumn<Contact, String> email;
    @FXML
    private TextField nameInput;
    @FXML
    private TextField phoneInput;

    @FXML
    private TextField streetInput;
    @FXML
    private TextField emailinput;
    @FXML
    Button Save;
    @FXML
    Button Delete;
    @FXML
    Button Edit;
    @FXML
    Button Add;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        nameColumn.setCellValueFactory(new PropertyValueFactory<Contact, String>("name"));
        phone.setCellValueFactory(new PropertyValueFactory<Contact, Integer>("phone"));
        Street.setCellValueFactory(new PropertyValueFactory<Contact, String>("street"));
        email.setCellValueFactory(new PropertyValueFactory<Contact, String>("email"));

    }
    //Submit button
    @FXML
    void submit(ActionEvent event) {String text = emailinput.getText();
        Contact contact = new Contact((nameInput.getText()),  (streetInput.getText()), (phone.getText()), emailinput.getText()

          );
        ObservableList<Contact> customers =  tableView.getItems(); //FXCollections.observableArrayList();
        customers.add(contact);
        tableView.setItems(customers);
    }

    @FXML
    void removecontact(ActionEvent event) {
        int selectedID = tableView.getSelectionModel().getSelectedIndex();
        tableView.getItems().remove(selectedID);
//        tableView.getItems().get(selectedID).getEmail()
    }
    @FXML
    void updatecontact(){
        int selectedID = tableView.getSelectionModel().getSelectedIndex();
        String mail=tableView.getItems().get(selectedID).getEmail();
        String fone=tableView.getItems().get(selectedID).getPhone();
        String str=tableView.getItems().get(selectedID).getStreet();
        String ename=tableView.getItems().get(selectedID).getName();
        emailinput.setText(mail);
        phoneInput.setText(fone);
        nameInput.setText(ename);
        streetInput.setText(str);
    }


}
