package com.example.phonebook;

import java.sql.Connection;
import java.sql.DriverManager;

public class dbconnection {
    public Connection connection;
    public   Connection getConnection(){
        String dname="phonebook";
        String username="root";
        String password="3864";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/"+dname,username,password);

        }catch (Exception e){
            e.printStackTrace();
        }
        return connection;
    }
}
